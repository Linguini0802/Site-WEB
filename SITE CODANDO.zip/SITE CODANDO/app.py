from flask import Flask, render_template, request, redirect, url_for
import functions as fc

app = Flask(__name__)

cadastros = fc.carregar_dados()

@app.route('/', methods='POST')
def login():

    if request.method == 'POST':
        usuario = request.form.get('login')
        senha = request.form.get('senha')


    

if __name__ == '__main__':
    app.run(debug=True)